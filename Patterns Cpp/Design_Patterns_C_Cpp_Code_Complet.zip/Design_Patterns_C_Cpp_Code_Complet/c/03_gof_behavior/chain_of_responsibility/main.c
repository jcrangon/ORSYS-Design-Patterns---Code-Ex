#include <stdio.h>

typedef struct Request { int authenticated; int rate_ok; } Request;
typedef struct Handler Handler;
struct Handler { int (*handle)(Handler*,Request*); Handler *next; };
static int terminal_handle(Handler *h,Request *r){ (void)h;(void)r; puts("business handler"); return 200; }
static int auth_handle(Handler *h,Request *r){ if(!r->authenticated) return 401; return h->next->handle(h->next,r); }
static int rate_handle(Handler *h,Request *r){ if(!r->rate_ok) return 429; return h->next->handle(h->next,r); }
int main(void){ Handler terminal={terminal_handle,NULL}, rate={rate_handle,&terminal}, auth={auth_handle,&rate}; Request a={1,1},b={0,1}; printf("a=%d b=%d\n",auth.handle(&auth,&a),auth.handle(&auth,&b)); return 0; }
