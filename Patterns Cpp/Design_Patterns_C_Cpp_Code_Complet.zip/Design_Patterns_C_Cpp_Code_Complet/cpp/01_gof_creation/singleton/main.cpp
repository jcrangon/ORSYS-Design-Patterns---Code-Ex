#include <iostream>
#include <mutex>
class Metrics {
    int requests_=0; std::mutex m_;
    Metrics()=default;
public:
    Metrics(const Metrics&)=delete; Metrics& operator=(const Metrics&)=delete;
    static Metrics& instance(){ static Metrics m; return m; }
    void inc(){ std::scoped_lock lk(m_); ++requests_; }
    int requests() const { return requests_; }
};
int main(){ Metrics::instance().inc(); Metrics::instance().inc(); std::cout<<Metrics::instance().requests()<<'\n'; }
