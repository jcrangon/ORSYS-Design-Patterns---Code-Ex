#include <array>
#include <cstdint>
#include <iostream>
#include <optional>
struct EntityId{std::uint32_t index,generation;};struct Slot{int value=0;std::uint32_t generation=0;bool used=false;};class Store{std::array<Slot,4>slots_{};public:std::optional<EntityId>create(int v){for(std::uint32_t i=0;i<slots_.size();i++)if(!slots_[i].used){slots_[i].used=true;slots_[i].value=v;return EntityId{i,slots_[i].generation};}return std::nullopt;}int*get(EntityId h){if(h.index>=slots_.size())return nullptr;auto&s=slots_[h.index];return s.used&&s.generation==h.generation?&s.value:nullptr;}void destroy(EntityId h){if(auto*p=get(h)){(void)p;auto&s=slots_[h.index];s.used=false;++s.generation;}}};int main(){Store s;auto h=*s.create(99);std::cout<<*s.get(h)<<'\n';s.destroy(h);std::cout<<(s.get(h)==nullptr)<<'\n';}
