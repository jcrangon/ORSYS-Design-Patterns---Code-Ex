#include <iostream>
#include <memory>
#include <string>
class Connection;
struct ConnState{virtual~ConnState()=default;virtual void send(Connection&,const std::string&)=0;};
class Connection{std::unique_ptr<ConnState> state_;public:explicit Connection(std::unique_ptr<ConnState>s):state_(std::move(s)){}void set(std::unique_ptr<ConnState>s){state_=std::move(s);}void send(const std::string&m){state_->send(*this,m);}};
struct Disconnected final:ConnState{void send(Connection&,const std::string&)override{std::cout<<"not connected\n";}};
struct Connected final:ConnState{void send(Connection&,const std::string&m)override{std::cout<<"sent: "<<m<<'\n';}};
int main(){Connection c(std::make_unique<Disconnected>());c.send("hello");c.set(std::make_unique<Connected>());c.send("hello");}
