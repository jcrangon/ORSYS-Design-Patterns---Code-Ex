#include "widget.hpp"
int main(){Widget w;w.setText("hello pimpl");w.draw();}
