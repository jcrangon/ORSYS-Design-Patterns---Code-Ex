#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Entity Entity;
struct Entity { char kind[24]; int hp; Entity *(*clone)(const Entity*); };
static Entity *entity_clone(const Entity *self){ Entity *e=malloc(sizeof *e); if(e) *e=*self; return e; }
static Entity enemy_prototype(const char *kind,int hp){ Entity e={.hp=hp,.clone=entity_clone}; snprintf(e.kind,sizeof e.kind,"%s",kind); return e; }
int main(void){
    Entity orc=enemy_prototype("orc",100); Entity *a=orc.clone(&orc); Entity *b=orc.clone(&orc);
    if(!a||!b){ free(a); free(b); return 1; }
    b->hp=80; printf("%s:%d  %s:%d\n",a->kind,a->hp,b->kind,b->hp); free(a); free(b); return 0;
}
