#include <functional>
#include <iostream>
#include <string>
#include <utility>
class Drawable{std::function<void()> draw_;public:template<class T>Drawable(T x):draw_([v=std::move(x)]{v.draw();}){}void draw()const{draw_();}};struct Circle{int r;void draw()const{std::cout<<"circle r="<<r<<'\n';}};struct Label{std::string s;void draw()const{std::cout<<"label "<<s<<'\n';}};int main(){Drawable a=Circle{5};Drawable b=Label{"hello"};a.draw();b.draw();}
