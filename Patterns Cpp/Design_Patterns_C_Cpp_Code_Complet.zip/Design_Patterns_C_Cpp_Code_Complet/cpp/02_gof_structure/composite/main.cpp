#include <iostream>
#include <memory>
#include <vector>
struct Node { virtual ~Node()=default; virtual int cost() const=0; };
class Leaf final: public Node { int value_; public: explicit Leaf(int v):value_(v){} int cost() const override { return value_; } };
class Group final: public Node { std::vector<std::unique_ptr<Node>> children_; public: void add(std::unique_ptr<Node> n){ children_.push_back(std::move(n)); } int cost() const override { int s=0; for(auto& n:children_) s+=n->cost(); return s; } };
int main(){ auto root=std::make_unique<Group>(); root->add(std::make_unique<Leaf>(10)); auto sub=std::make_unique<Group>(); sub->add(std::make_unique<Leaf>(20)); sub->add(std::make_unique<Leaf>(30)); root->add(std::move(sub)); std::cout<<root->cost()<<'\n'; }
