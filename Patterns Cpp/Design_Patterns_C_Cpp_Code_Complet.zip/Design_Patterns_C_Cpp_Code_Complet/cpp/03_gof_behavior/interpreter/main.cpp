#include <iostream>
#include <memory>
struct Expr { virtual ~Expr()=default; virtual bool eval(int x) const=0; };
struct Greater final: Expr { int limit; explicit Greater(int l):limit(l){} bool eval(int x) const override{return x>limit;} };
struct Const final: Expr { bool v; explicit Const(bool b):v(b){} bool eval(int) const override{return v;} };
struct And final: Expr { std::unique_ptr<Expr>a,b; And(std::unique_ptr<Expr>x,std::unique_ptr<Expr>y):a(std::move(x)),b(std::move(y)){} bool eval(int x) const override{return a->eval(x)&&b->eval(x);} };
int main(){ And e(std::make_unique<Greater>(100),std::make_unique<Const>(true)); std::cout<<e.eval(80)<<' '<<e.eval(120)<<'\n'; }
