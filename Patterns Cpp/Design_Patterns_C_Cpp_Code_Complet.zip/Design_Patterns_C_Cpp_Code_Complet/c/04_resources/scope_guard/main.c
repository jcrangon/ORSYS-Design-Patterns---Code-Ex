#include <stdio.h>
static int step1(void){puts("step1");return 0;}static int step2(void){puts("step2 fails");return -1;}int main(void){FILE*f=fopen("scope_guard.txt","w");if(!f)return 1;int rc=step1();if(rc)goto cleanup;rc=step2();if(rc)goto cleanup;fputs("done",f);cleanup:puts("cleanup");fclose(f);remove("scope_guard.txt");return rc?0:0;}
