#!/usr/bin/env bash
set -euo pipefail
cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug
cmake --build build -j"$(nproc 2>/dev/null || echo 2)"
ctest --test-dir build --output-on-failure
