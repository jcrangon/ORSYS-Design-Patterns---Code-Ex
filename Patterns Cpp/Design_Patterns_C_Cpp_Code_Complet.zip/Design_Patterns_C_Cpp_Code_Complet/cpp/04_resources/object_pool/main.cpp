#include <array>
#include <cstddef>
#include <iostream>
#include <optional>
#include <utility>

template<class T,std::size_t N>
class ObjectPool{
    std::array<T,N> objects_{}; std::array<bool,N> used_{};
public:
    class Lease{
        ObjectPool* pool_{}; T* ptr_{};
    public:
        Lease(ObjectPool& p,T& x):pool_(&p),ptr_(&x){}
        Lease(const Lease&)=delete; Lease& operator=(const Lease&)=delete;
        Lease(Lease&& o) noexcept:pool_(std::exchange(o.pool_,nullptr)),ptr_(std::exchange(o.ptr_,nullptr)){}
        ~Lease(){ if(pool_) pool_->release(*ptr_); }
        T& get(){return *ptr_;} T* operator->(){return ptr_;}
    };
    std::optional<Lease> acquire(){ for(std::size_t i=0;i<N;i++) if(!used_[i]){used_[i]=true;objects_[i].reset();return Lease(*this,objects_[i]);} return std::nullopt; }
private:
    void release(T& x){ used_[static_cast<std::size_t>(&x-objects_.data())]=false; }
};
struct Buffer{ std::array<unsigned char,256> data{}; std::size_t used=0; void reset(){used=0;} };
int main(){ ObjectPool<Buffer,4> pool; auto lease=pool.acquire(); if(!lease) return 1; (*lease)->data[0]=7; (*lease)->used=1; std::cout<<int((*lease)->data[0])<<'\n'; }
