# Design Patterns C / C++ — exemples complets exécutables

Ce dossier accompagne le manuel **Design Patterns en C & C++ — explications détaillées et exemples**.
Il contient des programmes autonomes couvrant l'ensemble du manuel.

## Contenu

### 1. GoF — Création
- Factory Method
- Abstract Factory
- Builder
- Prototype
- Singleton

### 2. GoF — Structure
- Adapter
- Bridge
- Composite
- Decorator
- Facade
- Flyweight
- Proxy

### 3. GoF — Comportement
- Chain of Responsibility
- Command
- Interpreter
- Iterator
- Mediator
- Memento
- Observer
- State
- Strategy
- Template Method
- Visitor

### 4. Mémoire et ressources
- Object Pool
- Memory Pool / Fixed Block Allocator
- Arena / Region Allocator
- Slab / Object Cache
- RAII
- Scope Guard / defer

### 5. Idiomes et patterns C / C++
- Opaque Handle
- Pimpl (C++), avec équivalent pointeur opaque en C
- Handle + génération
- Type Erasure
- CRTP (C++), avec analogue de polymorphisme statique en C
- Policy-Based Design
- Intrusive Containers
- Copy-on-Write
- Small Buffer Optimization
- Resource Manager / Object Handle

### 6. Concurrence et systèmes
- Producer-Consumer
- Thread Pool
- Active Object
- Reactor
- Proactor
- Half-Sync / Half-Async
- Double Buffer
- Ring Buffer

## Nombre d'exemples

Le projet contient **94 exécutables de démonstration** : une version C et une version C++ pour chaque entrée du manuel. Pour les idiomes intrinsèquement C++ (Pimpl, CRTP), le dossier C fournit l'analogue idiomatique correspondant afin de montrer comment résoudre le même problème en C.

## Compilation sous Linux / WSL

Prérequis :

- CMake 3.20+
- GCC / G++ ou Clang / Clang++
- pthreads

Depuis la racine :

```bash
./build.sh
```

ou manuellement :

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug
cmake --build build -j
ctest --test-dir build --output-on-failure
```

Les exécutables sont placés dans :

```text
build/bin/
```

Exemples :

```bash
./build/bin/c_04_resources_object_pool
./build/bin/cpp_03_gof_behavior_strategy
./build/bin/cpp_06_concurrency_reactor
```

## Organisation

```text
c/
  01_gof_creation/
  02_gof_structure/
  03_gof_behavior/
  04_resources/
  05_idioms/
  06_concurrency/

cpp/
  01_gof_creation/
  02_gof_structure/
  03_gof_behavior/
  04_resources/
  05_idioms/
  06_concurrency/
```

Chaque dossier contient un exemple complet avec `main` et tous les types nécessaires. Les exemples multi-fichiers (notamment Opaque Handle et Pimpl) montrent également le découpage header / implémentation.

## Niveau des exemples

Les programmes sont volontairement compacts pour rendre la structure du pattern visible, mais ils sont complets et compilables. Ils ne remplacent pas une implémentation de production : sécurité mémoire avancée, timeouts, annulation, backpressure, télémétrie, traitement détaillé des erreurs et portability multi-OS peuvent nécessiter des couches supplémentaires.

Les exemples Reactor utilisent `poll()` et `pipe()`, donc la compilation cible principalement Linux / WSL / Unix. Le reste du projet repose essentiellement sur C11 et C++20.
