#include <stdio.h>
static int stock_reserve(int item){ printf("stock reserve %d\n",item); return 1; }
static int payment_charge(int cents){ printf("payment %d cents\n",cents); return 1; }
static void order_save(int item){ printf("order saved for %d\n",item); }
static int checkout(int item,int cents){ if(!stock_reserve(item)) return 0; if(!payment_charge(cents)) return 0; order_save(item); return 1; }
int main(void){ printf("checkout=%s\n",checkout(42,1999)?"ok":"fail"); return 0; }
