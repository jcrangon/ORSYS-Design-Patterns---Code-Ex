#include <iostream>
#include <string>
class Editor { public: struct Memento{std::string text;std::size_t cursor;}; private: std::string text_; std::size_t cursor_=0; public: explicit Editor(std::string t):text_(std::move(t)),cursor_(text_.size()){} Memento snapshot() const{return{text_,cursor_};} void replace(std::string t){text_=std::move(t);cursor_=text_.size();} void restore(const Memento&m){text_=m.text;cursor_=m.cursor;} void print()const{std::cout<<text_<<'\n';} };
int main(){ Editor e("hello"); auto m=e.snapshot(); e.replace("changed"); e.print(); e.restore(m); e.print(); }
