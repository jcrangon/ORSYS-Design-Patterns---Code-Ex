#include <iostream>
#include <memory>
struct Request{ bool authenticated; bool rateOk; };
class Handler { protected: std::unique_ptr<Handler> next_; public: virtual ~Handler()=default; Handler& next(std::unique_ptr<Handler> n){ next_=std::move(n); return *next_; } virtual int handle(const Request& r){ return next_?next_->handle(r):200; } };
class Auth final: public Handler { public: int handle(const Request& r) override { return r.authenticated?Handler::handle(r):401; } };
class Rate final: public Handler { public: int handle(const Request& r) override { return r.rateOk?Handler::handle(r):429; } };
int main(){ auto root=std::make_unique<Auth>(); root->next(std::make_unique<Rate>()); std::cout<<root->handle({true,true})<<' '<<root->handle({false,true})<<'\n'; }
