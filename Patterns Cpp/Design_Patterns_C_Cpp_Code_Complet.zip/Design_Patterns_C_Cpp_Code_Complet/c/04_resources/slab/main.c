#include <stdio.h>
#include <string.h>
#include <stddef.h>
#define N 8
typedef struct{int fd;char state[16];}SocketCB;typedef struct{SocketCB objs[N];unsigned char used[N];}Slab;
static SocketCB*slab_alloc(Slab*s){for(int i=0;i<N;i++)if(!s->used[i]){s->used[i]=1;s->objs[i]=(SocketCB){.fd=-1};strcpy(s->objs[i].state,"new");return&s->objs[i];}return NULL;}
static void slab_free(Slab*s,SocketCB*p){ptrdiff_t i=p-s->objs;if(i>=0&&i<N)s->used[i]=0;}
int main(void){Slab s={0};SocketCB*p=slab_alloc(&s);if(!p)return 1;p->fd=10;printf("fd=%d state=%s\n",p->fd,p->state);slab_free(&s,p);return 0;}
