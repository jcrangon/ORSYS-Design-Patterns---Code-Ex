#include <iostream>
#include <string>
class Device { std::string name_; std::size_t sent_=0; public: explicit Device(std::string n):name_(std::move(n)){} void send(const std::string&s){sent_+=s.size();std::cout<<name_<<" sent="<<sent_<<'\n';} };
int main(){Device d("uart0");d.send("hello");}
