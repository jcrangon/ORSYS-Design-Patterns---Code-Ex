#include <stdio.h>
#include <stddef.h>
#define BLOCKS 16
#define BLOCK_SIZE 64
typedef union Block{union Block*next;max_align_t align;unsigned char bytes[BLOCK_SIZE];}Block;static Block blocks[BLOCKS];static Block*free_list;
static void pool_init(void){free_list=&blocks[0];for(int i=0;i<BLOCKS-1;i++)blocks[i].next=&blocks[i+1];blocks[BLOCKS-1].next=NULL;}
static void*pool_alloc(void){if(!free_list)return NULL;Block*b=free_list;free_list=b->next;return b->bytes;}
static void pool_free(void*p){if(!p)return;Block*b=(Block*)((unsigned char*)p - offsetof(Block,bytes));b->next=free_list;free_list=b;}
int main(void){pool_init();void*a=pool_alloc();void*b=pool_alloc();printf("a=%p b=%p\n",a,b);pool_free(a);pool_free(b);return 0;}
