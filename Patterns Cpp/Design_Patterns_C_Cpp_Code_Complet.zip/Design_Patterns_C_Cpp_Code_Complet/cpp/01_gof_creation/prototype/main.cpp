#include <iostream>
#include <memory>
#include <string>

struct Enemy { virtual ~Enemy()=default; virtual std::unique_ptr<Enemy> clone() const=0; virtual void hit(int)=0; virtual void print() const=0; };
class Orc final: public Enemy {
    int hp_;
public:
    explicit Orc(int hp=100):hp_(hp){}
    std::unique_ptr<Enemy> clone() const override { return std::make_unique<Orc>(*this); }
    void hit(int d) override { hp_-=d; }
    void print() const override { std::cout<<"orc hp="<<hp_<<'\n'; }
};
int main(){ Orc prototype{100}; auto a=prototype.clone(); auto b=prototype.clone(); b->hit(20); a->print(); b->print(); }
