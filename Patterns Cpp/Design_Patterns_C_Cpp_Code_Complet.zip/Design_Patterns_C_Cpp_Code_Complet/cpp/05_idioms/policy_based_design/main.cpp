#include <iostream>
struct NoDiscount{int apply(int c)const{return c;}};struct PremiumDiscount{int apply(int c)const{return c*90/100;}};template<class Policy>class Pricing{Policy p_;public:int price(int c)const{return p_.apply(c);}};int main(){Pricing<NoDiscount>a;Pricing<PremiumDiscount>b;std::cout<<a.price(1000)<<' '<<b.price(1000)<<'\n';}
