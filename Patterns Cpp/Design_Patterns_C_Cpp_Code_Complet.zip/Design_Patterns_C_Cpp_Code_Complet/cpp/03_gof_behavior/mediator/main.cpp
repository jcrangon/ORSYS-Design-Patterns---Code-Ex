#include <iostream>
class DialogMediator { bool advanced_=false; public: void advancedChanged(bool v){ advanced_=v; std::cout<<"button="<<advanced_<<" panel="<<advanced_<<'\n'; } };
class CheckBox { DialogMediator& m_; public: explicit CheckBox(DialogMediator& m):m_(m){} void set(bool v){ m_.advancedChanged(v); } };
int main(){ DialogMediator m; CheckBox c(m); c.set(true); }
