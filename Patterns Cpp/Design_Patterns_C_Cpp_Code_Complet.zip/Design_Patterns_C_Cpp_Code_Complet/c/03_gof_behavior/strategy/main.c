#include <stdio.h>
#include <stdlib.h>
typedef int (*CompareFn)(const void*,const void*);
static int asc(const void*a,const void*b){int x=*(const int*)a,y=*(const int*)b;return (x>y)-(x<y);}static int desc(const void*a,const void*b){return -asc(a,b);}static void print(const int*a,size_t n){for(size_t i=0;i<n;i++)printf("%d ",a[i]);putchar('\n');}
int main(void){int a[]={4,1,3,2};qsort(a,4,sizeof(int),asc);print(a,4);qsort(a,4,sizeof(int),desc);print(a,4);return 0;}
