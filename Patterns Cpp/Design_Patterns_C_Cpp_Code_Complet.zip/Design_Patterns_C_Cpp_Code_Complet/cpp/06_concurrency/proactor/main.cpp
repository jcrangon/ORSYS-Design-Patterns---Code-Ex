#include <chrono>
#include <functional>
#include <iostream>
#include <string>
#include <thread>
void asyncRead(std::function<void(std::string)> completion){std::thread([cb=std::move(completion)]{std::this_thread::sleep_for(std::chrono::milliseconds(20));cb("async-data");}).detach();}int main(){bool done=false;asyncRead([&](std::string data){std::cout<<"completed: "<<data<<'\n';done=true;});while(!done)std::this_thread::sleep_for(std::chrono::milliseconds(1));}
