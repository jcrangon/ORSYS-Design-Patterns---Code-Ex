#include <stdio.h>
#include <stdlib.h>
/* En C, l'idiome équivalent à Pimpl est naturellement le pointeur opaque. */
typedef struct Widget Widget;
struct Widget { int secret; };
static Widget*widget_create(void){Widget*w=malloc(sizeof*w);if(w)w->secret=42;return w;}
static void widget_draw(const Widget*w){printf("secret=%d\n",w->secret);}static void widget_destroy(Widget*w){free(w);}int main(void){Widget*w=widget_create();if(!w)return 1;widget_draw(w);widget_destroy(w);return 0;}
