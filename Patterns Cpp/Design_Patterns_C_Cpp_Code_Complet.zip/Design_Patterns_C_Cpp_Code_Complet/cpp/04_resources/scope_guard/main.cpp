#include <iostream>
#include <utility>
template<class F>class ScopeExit{F f_;bool active_=true;public:explicit ScopeExit(F f):f_(std::move(f)){}~ScopeExit(){if(active_)f_();}void release(){active_=false;}};
template<class F>ScopeExit<F>scope_exit(F f){return ScopeExit<F>(std::move(f));}
int main(){bool committed=false;auto rollback=scope_exit([&]{if(!committed)std::cout<<"rollback\n";});std::cout<<"update\n";committed=true;rollback.release();std::cout<<"commit\n";}
