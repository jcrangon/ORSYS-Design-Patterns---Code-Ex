#include <array>
#include <cstring>
#include <iostream>
#include <memory>
#include <string_view>
class SmallString{std::size_t len_=0;std::array<char,24>small_{};std::unique_ptr<char[]>heap_;public:explicit SmallString(std::string_view s):len_(s.size()){if(len_<small_.size()){std::memcpy(small_.data(),s.data(),len_);small_[len_]='\0';}else{heap_=std::make_unique<char[]>(len_+1);std::memcpy(heap_.get(),s.data(),len_);heap_[len_]='\0';}}const char*c_str()const{return heap_?heap_.get():small_.data();}bool heap()const{return(bool)heap_;}};int main(){SmallString a("short"),b("this is a much longer string than the inline buffer");std::cout<<a.c_str()<<" heap="<<a.heap()<<'\n'<<b.c_str()<<" heap="<<b.heap()<<'\n';}
