#include <iostream>
#include <string>
struct Channel { virtual ~Channel()=default; virtual void send(const std::string&)=0; };
struct Email final: Channel { void send(const std::string& m) override { std::cout<<"EMAIL: "<<m<<'\n'; } };
struct Sms final: Channel { void send(const std::string& m) override { std::cout<<"SMS: "<<m<<'\n'; } };
class Notification { protected: Channel& channel_; public: explicit Notification(Channel& c):channel_(c){} virtual ~Notification()=default; virtual void send(const std::string&)=0; };
class Alert final: public Notification { public: using Notification::Notification; void send(const std::string& m) override { channel_.send("ALERT: "+m); } };
int main(){ Email e; Sms s; Alert a(e); Alert b(s); a.send("disk full"); b.send("cpu high"); }
