#ifndef DEVICE_H
#define DEVICE_H
#include <stddef.h>
typedef struct Device Device;
Device *device_open(const char *name);
int device_send(Device *d,const void *data,size_t n);
void device_close(Device *d);
#endif
