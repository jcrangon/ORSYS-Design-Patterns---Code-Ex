#include <stdio.h>

/* C n'a pas de templates/héritage : analogue de polymorphisme statique via macro. */
typedef struct { const char *name; } User;
static void User_print(const User *u) { printf("User(%s)\n", u->name); }
#define PRINT(type, obj) type##_print(&(obj))

int main(void) {
    User u = {"Alice"};
    PRINT(User, u);
    return 0;
}
