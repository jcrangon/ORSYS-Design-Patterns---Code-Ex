#include <stdio.h>
#include <stdbool.h>
#include <string.h>

typedef struct { char url[128]; int timeout_ms; bool tls; } Request;
typedef struct { char url[128]; int timeout_ms; bool tls; bool has_url; } RequestBuilder;

static RequestBuilder request_builder(void){ return (RequestBuilder){.timeout_ms=1000,.tls=false,.has_url=false}; }
static RequestBuilder *builder_url(RequestBuilder *b,const char *url){ snprintf(b->url,sizeof b->url,"%s",url); b->has_url=true; return b; }
static RequestBuilder *builder_timeout(RequestBuilder *b,int ms){ b->timeout_ms=ms; return b; }
static RequestBuilder *builder_tls(RequestBuilder *b,bool tls){ b->tls=tls; return b; }
static bool builder_build(const RequestBuilder *b, Request *out){
    if(!b->has_url || b->timeout_ms<=0) return false;
    *out=(Request){.timeout_ms=b->timeout_ms,.tls=b->tls};
    snprintf(out->url,sizeof out->url,"%s",b->url); return true;
}
int main(void){
    RequestBuilder b=request_builder(); Request r;
    builder_tls(builder_timeout(builder_url(&b,"https://api.example"),1500),true);
    if(!builder_build(&b,&r)){ puts("invalid request"); return 1; }
    printf("url=%s timeout=%d tls=%s\n",r.url,r.timeout_ms,r.tls?"yes":"no"); return 0;
}
