#include <stdio.h>
#include <stddef.h>
#include <stdint.h>

#define CAP 8
#define NONE UINT16_MAX

typedef struct { unsigned char data[256]; size_t used; } PacketBuffer;
typedef struct { PacketBuffer objects[CAP]; uint16_t next[CAP]; uint16_t free_head; size_t in_use; size_t high_water; } PacketPool;

static void pool_init(PacketPool *p){
    for(uint16_t i=0;i<CAP-1;i++) p->next[i]=i+1;
    p->next[CAP-1]=NONE; p->free_head=0; p->in_use=0; p->high_water=0;
}
static PacketBuffer *pool_acquire(PacketPool *p){
    if(p->free_head==NONE) return NULL;
    uint16_t i=p->free_head; p->free_head=p->next[i]; p->objects[i].used=0;
    if(++p->in_use>p->high_water) p->high_water=p->in_use;
    return &p->objects[i];
}
static void pool_release(PacketPool *p,PacketBuffer *b){
    ptrdiff_t idx=b-p->objects; if(idx<0||idx>=CAP) return;
    uint16_t i=(uint16_t)idx; p->next[i]=p->free_head; p->free_head=i; if(p->in_use) --p->in_use;
}
int main(void){ PacketPool p; pool_init(&p); PacketBuffer *a=pool_acquire(&p),*b=pool_acquire(&p); if(!a||!b) return 1; a->data[0]=42; a->used=1; printf("a=%u in_use=%zu\n",a->data[0],p.in_use); pool_release(&p,a); pool_release(&p,b); printf("high_water=%zu\n",p.high_water); return 0; }
