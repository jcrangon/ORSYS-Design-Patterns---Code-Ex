#include <poll.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
typedef void(*ReadyFn)(int fd,void*ctx);typedef struct{int fd;ReadyFn fn;void*ctx;}Handler;static void on_readable(int fd,void*ctx){char buf[64]={0};ssize_t n=read(fd,buf,sizeof buf-1);if(n>0)printf("reactor received: %s\n",buf);*(int*)ctx=1;}int main(void){int fds[2];if(pipe(fds)!=0)return 1;int done=0;Handler h={fds[0],on_readable,&done};write(fds[1],"hello",5);while(!done){struct pollfd pfd={h.fd,POLLIN,0};if(poll(&pfd,1,1000)>0&&(pfd.revents&POLLIN))h.fn(h.fd,h.ctx);}close(fds[0]);close(fds[1]);return 0;}
