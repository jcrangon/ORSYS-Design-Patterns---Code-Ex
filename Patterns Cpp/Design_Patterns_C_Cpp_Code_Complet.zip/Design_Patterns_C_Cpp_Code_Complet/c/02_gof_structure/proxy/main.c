#include <stdio.h>
#include <stdlib.h>

typedef struct Image Image;
struct Image { void (*show)(Image*); void (*destroy)(Image*); };
typedef struct { Image base; const char *path; } RealImage;
static void real_show(Image *i){ RealImage *r=(RealImage*)i; printf("display %s\n",r->path); }
static void real_destroy(Image *i){ free(i); }
static RealImage *real_new(const char *p){ RealImage *r=malloc(sizeof *r); if(r) *r=(RealImage){{real_show,real_destroy},p}; return r; }
typedef struct { Image base; const char *path; RealImage *real; } Proxy;
static void proxy_show(Image *i){ Proxy *p=(Proxy*)i; if(!p->real){ puts("lazy load"); p->real=real_new(p->path); } if(p->real) p->real->base.show((Image*)p->real); }
static void proxy_destroy(Image *i){ Proxy *p=(Proxy*)i; if(p->real) p->real->base.destroy((Image*)p->real); free(p); }
static Proxy *proxy_new(const char *path){ Proxy *p=calloc(1,sizeof *p); if(p){ p->base=(Image){proxy_show,proxy_destroy}; p->path=path; } return p; }
int main(void){ Proxy *p=proxy_new("photo.png"); p->base.show((Image*)p); p->base.show((Image*)p); p->base.destroy((Image*)p); return 0; }
