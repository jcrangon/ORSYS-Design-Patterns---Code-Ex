#include <iostream>
#include <memory>
#include <string>
struct Writer { virtual ~Writer()=default; virtual void write(const std::string&)=0; };
struct ConsoleWriter final: Writer { void write(const std::string& s) override { std::cout<<s<<'\n'; } };
class PrefixWriter final: public Writer { std::unique_ptr<Writer> inner_; std::string prefix_; public: PrefixWriter(std::unique_ptr<Writer> i,std::string p):inner_(std::move(i)),prefix_(std::move(p)){} void write(const std::string& s) override { inner_->write(prefix_+s); } };
int main(){ std::unique_ptr<Writer> w=std::make_unique<ConsoleWriter>(); w=std::make_unique<PrefixWriter>(std::move(w),"[LOG] "); w->write("hello"); }
