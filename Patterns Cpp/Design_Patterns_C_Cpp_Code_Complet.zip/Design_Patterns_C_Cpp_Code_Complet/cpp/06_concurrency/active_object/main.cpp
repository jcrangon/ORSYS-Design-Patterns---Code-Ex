#include <condition_variable>
#include <iostream>
#include <mutex>
#include <optional>
#include <queue>
#include <string>
#include <thread>
class ActiveSerial{std::mutex m_;std::condition_variable cv_;std::queue<std::string>q_;bool stop_=false;std::jthread worker_;public:ActiveSerial():worker_([this]{for(;;){std::string m;{std::unique_lock lk(m_);cv_.wait(lk,[&]{return stop_||!q_.empty();});if(stop_&&q_.empty())return;m=std::move(q_.front());q_.pop();}std::cout<<"serial write: "<<m<<'\n';}}){}~ActiveSerial(){{std::lock_guard lk(m_);stop_=true;}cv_.notify_all();}void send(std::string m){{std::lock_guard lk(m_);q_.push(std::move(m));}cv_.notify_one();}};int main(){ActiveSerial s;s.send("A");s.send("B");}
