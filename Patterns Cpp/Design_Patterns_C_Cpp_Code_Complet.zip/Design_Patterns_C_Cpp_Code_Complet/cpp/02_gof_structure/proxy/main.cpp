#include <iostream>
#include <memory>
#include <string>
struct Image { virtual ~Image()=default; virtual void show()=0; };
class RealImage final: public Image { std::string path_; public: explicit RealImage(std::string p):path_(std::move(p)){ std::cout<<"load "<<path_<<'\n'; } void show() override { std::cout<<"display "<<path_<<'\n'; } };
class ImageProxy final: public Image { std::string path_; std::unique_ptr<RealImage> real_; public: explicit ImageProxy(std::string p):path_(std::move(p)){} void show() override { if(!real_) real_=std::make_unique<RealImage>(path_); real_->show(); } };
int main(){ ImageProxy p("photo.png"); p.show(); p.show(); }
