#include <stdbool.h>
#include <stdio.h>
#define CAP 8
typedef struct{int data[CAP];size_t head,tail;}Ring;static bool push(Ring*r,int x){size_t n=(r->head+1)%CAP;if(n==r->tail)return false;r->data[r->head]=x;r->head=n;return true;}static bool pop(Ring*r,int*out){if(r->tail==r->head)return false;*out=r->data[r->tail];r->tail=(r->tail+1)%CAP;return true;}int main(void){Ring r={0};for(int i=1;i<=5;i++)push(&r,i);int x;while(pop(&r,&x))printf("%d ",x);putchar('\n');return 0;}
