@echo off
mvn test
