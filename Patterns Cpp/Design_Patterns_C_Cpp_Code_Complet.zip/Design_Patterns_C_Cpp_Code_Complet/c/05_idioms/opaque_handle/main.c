#include "device.h"
#include <string.h>
int main(void){ Device*d=device_open("uart0"); if(!d)return 1; const char*m="hello"; device_send(d,m,strlen(m)); device_close(d); return 0; }
