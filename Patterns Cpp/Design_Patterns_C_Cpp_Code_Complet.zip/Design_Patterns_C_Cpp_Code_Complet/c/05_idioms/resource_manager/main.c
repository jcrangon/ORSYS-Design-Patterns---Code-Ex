#include <stdint.h>
#include <stdio.h>
#include <string.h>
#define CAP 8
typedef uint32_t TextureId;typedef struct{char name[32];int loaded;}Texture;typedef struct{Texture textures[CAP];uint32_t count;}ResourceManager;static TextureId texture_load(ResourceManager*rm,const char*name){TextureId id=rm->count++;snprintf(rm->textures[id].name,sizeof rm->textures[id].name,"%s",name);rm->textures[id].loaded=1;return id;}static Texture*texture_resolve(ResourceManager*rm,TextureId id){return id<rm->count&&rm->textures[id].loaded?&rm->textures[id]:NULL;}static void texture_reload(ResourceManager*rm,TextureId id){Texture*t=texture_resolve(rm,id);if(t)printf("reload %s\n",t->name);}int main(void){ResourceManager rm={0};TextureId id=texture_load(&rm,"hero.png");printf("use %s\n",texture_resolve(&rm,id)->name);texture_reload(&rm,id);return 0;}
