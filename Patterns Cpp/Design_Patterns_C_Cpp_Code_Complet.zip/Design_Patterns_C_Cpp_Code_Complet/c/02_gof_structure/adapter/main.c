#include <stdint.h>
#include <stdio.h>
#include <string.h>

typedef struct { int writes; } Vendor;
static int vendor_write(Vendor *v,const uint8_t *p,size_t n,int flags){ (void)flags; ++v->writes; fwrite(p,1,n,stdout); putchar('\n'); return (int)n; }
typedef struct { void *ctx; int (*send)(void*,const uint8_t*,size_t); } Transport;
static int vendor_send(void *ctx,const uint8_t *p,size_t n){ return vendor_write((Vendor*)ctx,p,n,0)==(int)n; }
static int checkout_send(Transport t,const char *msg){ return t.send(t.ctx,(const uint8_t*)msg,strlen(msg)); }
int main(void){ Vendor v={0}; Transport t={&v,vendor_send}; printf("ok=%d\n",checkout_send(t,"HELLO")); return 0; }
