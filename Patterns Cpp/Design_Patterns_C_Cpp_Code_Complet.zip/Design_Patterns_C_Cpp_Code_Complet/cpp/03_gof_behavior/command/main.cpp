#include <iostream>
#include <memory>
struct Command { virtual ~Command()=default; virtual void execute()=0; virtual void undo()=0; };
class Counter { public: int value=0; };
class Increment final: public Command { Counter& c_; public: explicit Increment(Counter& c):c_(c){} void execute() override{++c_.value;} void undo() override{--c_.value;} };
int main(){ Counter c; std::unique_ptr<Command> cmd=std::make_unique<Increment>(c); cmd->execute(); cmd->execute(); std::cout<<c.value<<'\n'; cmd->undo(); std::cout<<c.value<<'\n'; }
