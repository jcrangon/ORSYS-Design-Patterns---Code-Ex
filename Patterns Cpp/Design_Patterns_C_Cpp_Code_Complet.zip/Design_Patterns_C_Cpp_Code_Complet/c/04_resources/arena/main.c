#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <stdalign.h>
#include <string.h>
typedef struct{unsigned char*base;size_t capacity,offset;}Arena;
static void*arena_alloc(Arena*a,size_t n,size_t align){uintptr_t p=(uintptr_t)(a->base+a->offset);uintptr_t aligned=(p+align-1)&~(uintptr_t)(align-1);size_t newoff=(size_t)(aligned-(uintptr_t)a->base)+n;if(newoff>a->capacity)return NULL;a->offset=newoff;return(void*)aligned;}
static void arena_reset(Arena*a){a->offset=0;}
int main(void){unsigned char storage[1024];Arena a={storage,sizeof storage,0};int*x=arena_alloc(&a,sizeof(int),alignof(int));char*s=arena_alloc(&a,32,alignof(char));if(!x||!s)return 1;*x=42;strcpy(s,"hello arena");printf("%d %s used=%zu\n",*x,s,a.offset);arena_reset(&a);printf("used=%zu\n",a.offset);return 0;}
