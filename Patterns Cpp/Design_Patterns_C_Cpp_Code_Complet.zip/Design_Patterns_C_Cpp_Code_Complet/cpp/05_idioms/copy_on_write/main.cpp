#include <iostream>
#include <memory>
#include <vector>
class Image{std::shared_ptr<std::vector<unsigned char>>buf_;void detach(){if(!buf_.unique())buf_=std::make_shared<std::vector<unsigned char>>(*buf_);}public:explicit Image(std::size_t n):buf_(std::make_shared<std::vector<unsigned char>>(n)){}void set(std::size_t i,unsigned char v){detach();(*buf_)[i]=v;}unsigned char get(std::size_t i)const{return(*buf_)[i];}};int main(){Image a(4);Image b=a;b.set(0,7);std::cout<<int(a.get(0))<<' '<<int(b.get(0))<<'\n';}
