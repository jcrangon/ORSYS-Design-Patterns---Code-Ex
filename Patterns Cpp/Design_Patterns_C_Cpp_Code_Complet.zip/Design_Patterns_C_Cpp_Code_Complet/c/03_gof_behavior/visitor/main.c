#include <stdio.h>
typedef struct Number{int value;}Number;typedef struct Add{Number left,right;}Add;typedef struct Visitor Visitor;struct Visitor{void(*number)(Visitor*,Number*);void(*add)(Visitor*,Add*);int acc;};
static void visit_number(Visitor*v,Number*n){v->acc+=n->value;}static void visit_add(Visitor*v,Add*a){visit_number(v,&a->left);visit_number(v,&a->right);}int main(void){Add e={{2},{3}};Visitor v={visit_number,visit_add,0};v.add(&v,&e);printf("sum=%d\n",v.acc);return 0;}
