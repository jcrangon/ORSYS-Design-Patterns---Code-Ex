#include <stdbool.h>
#include <stdio.h>

typedef struct { int data[5]; size_t size; } IntList;
typedef struct { const IntList *list; size_t index; } IntIterator;
static IntIterator iter(const IntList *l){ return (IntIterator){l,0}; }
static bool next(IntIterator *it,int *out){ if(it->index>=it->list->size) return false; *out=it->list->data[it->index++]; return true; }
int main(void){ IntList l={{1,2,3,4,5},5}; IntIterator it=iter(&l); int x; while(next(&it,&x)) printf("%d ",x); putchar('\n'); return 0; }
