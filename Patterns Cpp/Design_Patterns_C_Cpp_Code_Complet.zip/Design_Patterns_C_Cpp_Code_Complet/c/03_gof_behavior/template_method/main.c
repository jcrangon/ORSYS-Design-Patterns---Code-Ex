#include <stdio.h>
#include <string.h>
typedef struct{const char*(*read)(const char*);int(*validate)(const char*);}ImportHooks;
static const char*csv_read(const char*s){printf("read csv %s\n",s);return"row1";}static int csv_validate(const char*d){return strlen(d)>0;}
static const char*json_read(const char*s){printf("read json %s\n",s);return"{}";}static int json_validate(const char*d){return d[0]=='{';}
static void import_run(const char*src,ImportHooks h){const char*d=h.read(src);if(h.validate(d))printf("save %s\n",d);else puts("invalid");}
int main(void){import_run("a.csv",(ImportHooks){csv_read,csv_validate});import_run("a.json",(ImportHooks){json_read,json_validate});return 0;}
