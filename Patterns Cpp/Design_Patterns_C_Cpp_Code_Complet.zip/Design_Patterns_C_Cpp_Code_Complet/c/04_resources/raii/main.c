#include <stdio.h>
int main(void){FILE*f=fopen("raii_demo.txt","w");if(!f){perror("fopen");return 1;}int rc=0;if(fputs("hello\n",f)<0){rc=2;goto cleanup;}puts("written");cleanup:if(fclose(f)!=0&&rc==0)rc=3;remove("raii_demo.txt");return rc;}
