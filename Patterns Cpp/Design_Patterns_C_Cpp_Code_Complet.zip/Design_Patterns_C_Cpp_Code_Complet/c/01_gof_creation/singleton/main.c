#include <pthread.h>
#include <stdio.h>

typedef struct { int requests; pthread_mutex_t lock; } Metrics;
static Metrics g_metrics; static pthread_once_t once=PTHREAD_ONCE_INIT;
static void metrics_init_once(void){ g_metrics.requests=0; pthread_mutex_init(&g_metrics.lock,NULL); }
static Metrics *metrics_instance(void){ pthread_once(&once,metrics_init_once); return &g_metrics; }
static void metrics_inc(void){ Metrics *m=metrics_instance(); pthread_mutex_lock(&m->lock); ++m->requests; pthread_mutex_unlock(&m->lock); }
int main(void){ metrics_inc(); metrics_inc(); printf("requests=%d\n",metrics_instance()->requests); return 0; }
