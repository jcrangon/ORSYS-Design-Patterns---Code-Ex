#include <stdio.h>
typedef struct{int frame_no;char text[32];}Frame;int main(void){Frame frames[2]={{0},{0}};Frame*front=&frames[0],*back=&frames[1];for(int i=1;i<=3;i++){back->frame_no=i;snprintf(back->text,sizeof back->text,"frame-%d",i);Frame*tmp=front;front=back;back=tmp;printf("display %d %s\n",front->frame_no,front->text);}return 0;}
