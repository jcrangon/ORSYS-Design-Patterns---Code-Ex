#include <array>
#include <bitset>
#include <cstddef>
#include <iostream>
#include <memory>
#include <new>
#include <utility>
template<class T,std::size_t N>class Slab{alignas(T) std::array<std::byte,sizeof(T)*N> mem_{};std::bitset<N> used_;T*ptr(std::size_t i){return reinterpret_cast<T*>(mem_.data()+i*sizeof(T));}public:template<class...A>T*create(A&&...a){for(std::size_t i=0;i<N;i++)if(!used_[i]){used_.set(i);return std::construct_at(ptr(i),std::forward<A>(a)...);}return nullptr;}void destroy(T*p){auto i=static_cast<std::size_t>((reinterpret_cast<std::byte*>(p)-mem_.data())/sizeof(T));std::destroy_at(p);used_.reset(i);}};struct SocketCB{int fd;explicit SocketCB(int f):fd(f){}};int main(){Slab<SocketCB,4>s;auto*p=s.create(10);std::cout<<p->fd<<'\n';s.destroy(p);}
