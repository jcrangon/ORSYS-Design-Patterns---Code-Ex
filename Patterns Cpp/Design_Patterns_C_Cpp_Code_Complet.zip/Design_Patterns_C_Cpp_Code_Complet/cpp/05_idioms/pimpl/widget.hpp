#pragma once
#include <memory>
class Widget {
    struct Impl;
    std::unique_ptr<Impl> p_;
public:
    Widget();
    ~Widget();
    Widget(Widget&&) noexcept;
    Widget& operator=(Widget&&) noexcept;
    Widget(const Widget&)=delete;
    Widget& operator=(const Widget&)=delete;
    void draw() const;
    void setText(const char *text);
};
