#include <condition_variable>
#include <iostream>
#include <mutex>
#include <queue>
#include <thread>
class Queue{std::mutex m_;std::condition_variable cv_;std::queue<int>q_;bool stop_=false;public:void push(int x){{std::lock_guard lk(m_);q_.push(x);}cv_.notify_one();}bool pop(int&x){std::unique_lock lk(m_);cv_.wait(lk,[&]{return stop_||!q_.empty();});if(q_.empty())return false;x=q_.front();q_.pop();return true;}void stop(){{std::lock_guard lk(m_);stop_=true;}cv_.notify_all();}};int main(){Queue q;std::jthread worker([&]{int x;while(q.pop(x))std::cout<<"sync handle "<<x<<'\n';});for(int i=0;i<5;i++){std::cout<<"async receive "<<i<<'\n';q.push(i);}q.stop();}
