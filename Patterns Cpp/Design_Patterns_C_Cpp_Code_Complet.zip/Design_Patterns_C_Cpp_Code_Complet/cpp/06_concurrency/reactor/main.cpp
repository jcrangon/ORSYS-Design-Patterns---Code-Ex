#include <poll.h>
#include <unistd.h>
#include <functional>
#include <iostream>
#include <string>
class Reactor{int fd_;std::function<void(int)>handler_;public:void onReadable(int fd,std::function<void(int)>h){fd_=fd;handler_=std::move(h);}void runOnce(){pollfd pfd{fd_,POLLIN,0};if(poll(&pfd,1,1000)>0&&(pfd.revents&POLLIN))handler_(fd_);}};int main(){int fds[2];if(pipe(fds)!=0)return 1;Reactor r;r.onReadable(fds[0],[](int fd){char b[64]={0};auto n=read(fd,b,63);if(n>0)std::cout<<"reactor received: "<<b<<'\n';});write(fds[1],"hello",5);r.runOnce();close(fds[0]);close(fds[1]);}
