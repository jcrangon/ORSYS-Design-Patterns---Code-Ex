#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#define WORKERS 3
typedef void(*JobFn)(void*);typedef struct Job{JobFn fn;void*ctx;struct Job*next;}Job;typedef struct{pthread_t workers[WORKERS];Job*head,*tail;pthread_mutex_t m;pthread_cond_t cv;bool stop;}ThreadPool;
static void*worker(void*arg){ThreadPool*p=arg;for(;;){pthread_mutex_lock(&p->m);while(!p->head&&!p->stop)pthread_cond_wait(&p->cv,&p->m);if(p->stop&&!p->head){pthread_mutex_unlock(&p->m);break;}Job*j=p->head;p->head=j->next;if(!p->head)p->tail=NULL;pthread_mutex_unlock(&p->m);j->fn(j->ctx);free(j);}return NULL;}static void pool_init(ThreadPool*p){*p=(ThreadPool){0};pthread_mutex_init(&p->m,NULL);pthread_cond_init(&p->cv,NULL);for(int i=0;i<WORKERS;i++)pthread_create(&p->workers[i],NULL,worker,p);}static void submit(ThreadPool*p,JobFn fn,void*ctx){Job*j=malloc(sizeof*j);*j=(Job){fn,ctx,NULL};pthread_mutex_lock(&p->m);if(p->tail)p->tail->next=j;else p->head=j;p->tail=j;pthread_cond_signal(&p->cv);pthread_mutex_unlock(&p->m);}static void pool_stop(ThreadPool*p){pthread_mutex_lock(&p->m);p->stop=true;pthread_cond_broadcast(&p->cv);pthread_mutex_unlock(&p->m);for(int i=0;i<WORKERS;i++)pthread_join(p->workers[i],NULL);}static void print_job(void*ctx){printf("job %d thread=%lu\n",*(int*)ctx,(unsigned long)pthread_self());}
int main(void){ThreadPool p;pool_init(&p);int ids[6];for(int i=0;i<6;i++){ids[i]=i;submit(&p,print_job,&ids[i]);}pool_stop(&p);return 0;}
