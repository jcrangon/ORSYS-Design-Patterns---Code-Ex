#include <stdio.h>
#include <string.h>

typedef struct { const char *font; int size; int color; } GlyphStyle;
typedef struct { char ch; int x,y; const GlyphStyle *style; } Glyph;
static GlyphStyle styles[4]; static int style_count=0;
static const GlyphStyle *style_get(const char *font,int size,int color){
    for(int i=0;i<style_count;i++) if(styles[i].size==size&&styles[i].color==color&&strcmp(styles[i].font,font)==0) return &styles[i];
    styles[style_count]=(GlyphStyle){font,size,color}; return &styles[style_count++];
}
int main(void){ const GlyphStyle *s=style_get("Mono",12,0); Glyph a={'A',10,20,s}, b={'B',20,20,s}; printf("%c/%c share style=%s\n",a.ch,b.ch,a.style==b.style?"yes":"no"); return 0; }
