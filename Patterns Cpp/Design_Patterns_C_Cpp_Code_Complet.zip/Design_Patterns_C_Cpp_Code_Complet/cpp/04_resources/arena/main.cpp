#include <array>
#include <cstddef>
#include <iostream>
#include <memory_resource>
#include <string>
#include <vector>
int main(){ std::array<std::byte,4096> storage{}; std::pmr::monotonic_buffer_resource arena(storage.data(),storage.size()); std::pmr::vector<std::pmr::string> words{&arena}; words.emplace_back("alpha"); words.emplace_back("beta"); for(auto&s:words)std::cout<<s<<' '; std::cout<<'\n'; arena.release(); }
