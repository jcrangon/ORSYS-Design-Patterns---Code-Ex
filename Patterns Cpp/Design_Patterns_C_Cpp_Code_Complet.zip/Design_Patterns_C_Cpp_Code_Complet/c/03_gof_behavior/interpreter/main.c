#include <stdio.h>
#include <stdlib.h>

typedef enum { CONST, GT, AND } Kind;
typedef struct Expr Expr;
struct Expr { Kind kind; int value; Expr *a,*b; };
static int eval(const Expr *e,int x){ switch(e->kind){ case CONST:return e->value; case GT:return x>e->value; case AND:return eval(e->a,x)&&eval(e->b,x); } return 0; }
int main(void){ Expr gt={GT,100,NULL,NULL}, yes={CONST,1,NULL,NULL}, both={AND,0,&gt,&yes}; printf("80=%d 120=%d\n",eval(&both,80),eval(&both,120)); return 0; }
