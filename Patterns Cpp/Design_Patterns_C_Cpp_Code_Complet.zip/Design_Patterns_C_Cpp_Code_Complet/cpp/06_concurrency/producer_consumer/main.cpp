#include <condition_variable>
#include <iostream>
#include <mutex>
#include <optional>
#include <queue>
#include <thread>
template<class T>class BlockingQueue{std::mutex m_;std::condition_variable cv_;std::queue<T>q_;bool closed_=false;public:void push(T v){{std::lock_guard lk(m_);q_.push(std::move(v));}cv_.notify_one();}std::optional<T>pop(){std::unique_lock lk(m_);cv_.wait(lk,[&]{return closed_||!q_.empty();});if(q_.empty())return std::nullopt;T v=std::move(q_.front());q_.pop();return v;}void close(){{std::lock_guard lk(m_);closed_=true;}cv_.notify_all();}};int main(){BlockingQueue<int>q;std::jthread c([&]{while(auto v=q.pop())std::cout<<"consume "<<*v<<'\n';});for(int i=1;i<=5;i++)q.push(i);q.close();}
