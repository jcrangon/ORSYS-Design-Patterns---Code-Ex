#include "widget.hpp"
#include <iostream>
#include <string>
struct Widget::Impl { std::string text="default"; int internalCache=42; };
Widget::Widget():p_(std::make_unique<Impl>()){}
Widget::~Widget()=default;
Widget::Widget(Widget&&) noexcept=default;
Widget& Widget::operator=(Widget&&) noexcept=default;
void Widget::draw() const { std::cout<<"Widget: "<<p_->text<<" cache="<<p_->internalCache<<'\n'; }
void Widget::setText(const char *text){p_->text=text;}
