#include <iostream>
class Stock { public: bool reserve(int id){ std::cout<<"reserve "<<id<<'\n'; return true; } };
class Payments { public: bool charge(int c){ std::cout<<"charge "<<c<<'\n'; return true; } };
class Orders { public: void save(int id){ std::cout<<"save "<<id<<'\n'; } };
class CheckoutFacade { Stock stock_; Payments pay_; Orders orders_; public: bool checkout(int id,int cents){ if(!stock_.reserve(id)||!pay_.charge(cents)) return false; orders_.save(id); return true; } };
int main(){ CheckoutFacade f; std::cout<<std::boolalpha<<f.checkout(42,1999)<<'\n'; }
