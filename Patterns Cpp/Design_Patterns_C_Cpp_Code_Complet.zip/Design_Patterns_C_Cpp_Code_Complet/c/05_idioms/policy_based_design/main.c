#include <stdio.h>
typedef int(*DiscountPolicy)(int cents);static int no_discount(int c){return c;}static int premium(int c){return c*90/100;}typedef struct{DiscountPolicy discount;}Pricing;static int price(Pricing*p,int cents){return p->discount(cents);}int main(void){Pricing a={no_discount},b={premium};printf("%d %d\n",price(&a,1000),price(&b,1000));return 0;}
