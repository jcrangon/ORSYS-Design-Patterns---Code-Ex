#include <iostream>
#include <memory>
#include <string>

struct Parser {
    virtual ~Parser() = default;
    virtual void parse(const std::string& data) = 0;
};
struct CsvParser final : Parser {
    void parse(const std::string& data) override { std::cout << "CSV: " << data << '\n'; }
};
struct JsonParser final : Parser {
    void parse(const std::string& data) override { std::cout << "JSON: " << data << '\n'; }
};

class Importer {
public:
    virtual ~Importer() = default;
    void run(const std::string& data) {
        auto p = makeParser();
        p->parse(data);
    }
protected:
    virtual std::unique_ptr<Parser> makeParser() const = 0;
};
class CsvImporter final : public Importer {
    std::unique_ptr<Parser> makeParser() const override { return std::make_unique<CsvParser>(); }
};
class JsonImporter final : public Importer {
    std::unique_ptr<Parser> makeParser() const override { return std::make_unique<JsonParser>(); }
};

int main() {
    CsvImporter{}.run("id,name\\n1,Alice");
    JsonImporter{}.run(R"({"id":1})");
}
