#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct{size_t len;bool heap;union{char small[24];char*ptr;}data;}SmallString;static int ss_init(SmallString*s,const char*text){s->len=strlen(text);s->heap=s->len>=sizeof s->data.small;if(s->heap){s->data.ptr=malloc(s->len+1);if(!s->data.ptr)return 0;memcpy(s->data.ptr,text,s->len+1);}else memcpy(s->data.small,text,s->len+1);return 1;}static const char*ss_cstr(const SmallString*s){return s->heap?s->data.ptr:s->data.small;}static void ss_destroy(SmallString*s){if(s->heap)free(s->data.ptr);}int main(void){SmallString a,b;ss_init(&a,"short");ss_init(&b,"this text is definitely longer than twenty three chars");printf("%s heap=%d\n%s heap=%d\n",ss_cstr(&a),a.heap,ss_cstr(&b),b.heap);ss_destroy(&a);ss_destroy(&b);return 0;}
