#include <cstdio>
#include <iostream>
#include <stdexcept>
class File{FILE*f_;public:explicit File(const char*p):f_(std::fopen(p,"w")){if(!f_)throw std::runtime_error("open");}~File(){if(f_)std::fclose(f_);}File(const File&)=delete;File&operator=(const File&)=delete;void write(const char*s){std::fputs(s,f_);}};
int main(){try{File f("raii_demo_cpp.txt");f.write("hello\n");std::cout<<"resource closed automatically\n";}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}std::remove("raii_demo_cpp.txt");}
