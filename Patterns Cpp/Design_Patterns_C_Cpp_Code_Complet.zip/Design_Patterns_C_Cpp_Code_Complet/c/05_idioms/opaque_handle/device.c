#include "device.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct Device { char name[64]; size_t bytes_sent; };
Device *device_open(const char *name){ Device*d=calloc(1,sizeof *d); if(!d)return NULL; snprintf(d->name,sizeof d->name,"%s",name); return d; }
int device_send(Device*d,const void*data,size_t n){ if(!d||!data)return 0; d->bytes_sent+=n; printf("[%s] send %zu bytes (total=%zu)\n",d->name,n,d->bytes_sent); return 1; }
void device_close(Device*d){ free(d); }
