#include <stdio.h>
typedef struct Node{struct Node*next;}Node;typedef struct{int id;Node link;}Task;static Task*task_from_node(Node*n){return(Task*)((char*)n-(size_t)&((Task*)0)->link);}int main(void){Task a={1,{0}},b={2,{0}},c={3,{0}};a.link.next=&b.link;b.link.next=&c.link;for(Node*n=&a.link;n;n=n->next)printf("task=%d\n",task_from_node(n)->id);return 0;}
