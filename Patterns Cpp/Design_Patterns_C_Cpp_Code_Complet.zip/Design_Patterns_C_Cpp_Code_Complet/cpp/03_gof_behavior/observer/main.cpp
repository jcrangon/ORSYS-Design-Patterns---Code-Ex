#include <functional>
#include <iostream>
#include <vector>
struct Event{int orderId;};
class Bus{std::vector<std::function<void(const Event&)>> subs_;public:void subscribe(std::function<void(const Event&)> f){subs_.push_back(std::move(f));}void publish(const Event&e){for(auto&f:subs_)f(e);}};
int main(){Bus b;int count=0;b.subscribe([](auto e){std::cout<<"email "<<e.orderId<<'\n';});b.subscribe([&](auto e){++count;std::cout<<"analytics "<<count<<'\n';});b.publish({42});}
