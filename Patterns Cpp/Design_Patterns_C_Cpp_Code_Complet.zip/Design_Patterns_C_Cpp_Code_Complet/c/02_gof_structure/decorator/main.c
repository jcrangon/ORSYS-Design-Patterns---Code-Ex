#include <stdio.h>
#include <string.h>

typedef struct Writer Writer;
struct Writer { void *ctx; void (*write)(Writer*,const char*); };
static void console_write(Writer *self,const char *s){ (void)self; printf("%s\n",s); }
typedef struct { Writer base; Writer *inner; const char *prefix; } PrefixDecorator;
static void prefix_write(Writer *self,const char *s){ PrefixDecorator *d=(PrefixDecorator*)self; char buf[256]; snprintf(buf,sizeof buf,"%s%s",d->prefix,s); d->inner->write(d->inner,buf); }
int main(void){ Writer console={NULL,console_write}; PrefixDecorator d={{NULL,prefix_write},&console,"[LOG] "}; d.base.write((Writer*)&d,"hello"); return 0; }
