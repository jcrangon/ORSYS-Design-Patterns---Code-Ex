#include <iostream>
#include <string>
#include <vector>
struct TextureId{std::size_t value;};struct Texture{std::string name;};class ResourceManager{std::vector<Texture>textures_;public:TextureId load(std::string n){textures_.push_back({std::move(n)});return{textures_.size()-1};}Texture&get(TextureId id){return textures_.at(id.value);}void reload(TextureId id){std::cout<<"reload "<<get(id).name<<'\n';}};int main(){ResourceManager rm;auto id=rm.load("hero.png");std::cout<<rm.get(id).name<<'\n';rm.reload(id);}
