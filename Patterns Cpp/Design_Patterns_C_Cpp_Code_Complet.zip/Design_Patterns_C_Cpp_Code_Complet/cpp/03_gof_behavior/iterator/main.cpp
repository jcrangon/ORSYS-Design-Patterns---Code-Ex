#include <array>
#include <iostream>
class Range { int first_,last_; public: class Iterator { int v_; public: explicit Iterator(int v):v_(v){} int operator*() const{return v_;} Iterator& operator++(){++v_; return *this;} bool operator!=(const Iterator& o) const{return v_!=o.v_;} }; Range(int a,int b):first_(a),last_(b){} Iterator begin() const{return Iterator(first_);} Iterator end() const{return Iterator(last_);} };
int main(){ for(int x:Range(1,6)) std::cout<<x<<' '; std::cout<<'\n'; }
