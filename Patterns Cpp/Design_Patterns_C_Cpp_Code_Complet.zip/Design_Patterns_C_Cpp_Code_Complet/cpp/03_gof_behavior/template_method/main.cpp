#include <iostream>
#include <string>
class Importer{public:virtual~Importer()=default;void run(const std::string&s){auto d=read(s);if(validate(d))save(d);}protected:virtual std::string read(const std::string&)=0;virtual bool validate(const std::string&)=0;void save(const std::string&d){std::cout<<"save "<<d<<'\n';}};
class Csv final:public Importer{std::string read(const std::string&s)override{std::cout<<"read "<<s<<'\n';return"row";}bool validate(const std::string&d)override{return!d.empty();}};
int main(){Csv c;c.run("a.csv");}
