#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct { char text[128]; size_t cursor; } Editor;
typedef struct { char text[128]; size_t cursor; } EditorMemento;
static EditorMemento snapshot(const Editor *e){ EditorMemento m; memcpy(&m,e,sizeof m); return m; }
static void restore(Editor *e,const EditorMemento *m){ memcpy(e,m,sizeof *e); }
int main(void){ Editor e={"hello",5}; EditorMemento m=snapshot(&e); strcpy(e.text,"changed"); e.cursor=7; printf("now=%s\n",e.text); restore(&e,&m); printf("restored=%s\n",e.text); return 0; }
