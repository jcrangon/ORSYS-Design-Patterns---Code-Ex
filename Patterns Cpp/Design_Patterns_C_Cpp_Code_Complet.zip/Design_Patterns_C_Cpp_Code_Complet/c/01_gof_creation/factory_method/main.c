#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Parser Parser;
struct Parser {
    const char *name;
    void (*parse)(Parser *self, const char *data);
    void (*destroy)(Parser *self);
};

static void csv_parse(Parser *self, const char *data) {
    printf("[%s] CSV parse: %s\n", self->name, data);
}
static void json_parse(Parser *self, const char *data) {
    printf("[%s] JSON parse: %s\n", self->name, data);
}
static void parser_destroy(Parser *self) { free(self); }

static Parser *make_csv_parser(void) {
    Parser *p = malloc(sizeof *p);
    if (!p) return NULL;
    *p = (Parser){"CsvParser", csv_parse, parser_destroy};
    return p;
}
static Parser *make_json_parser(void) {
    Parser *p = malloc(sizeof *p);
    if (!p) return NULL;
    *p = (Parser){"JsonParser", json_parse, parser_destroy};
    return p;
}

typedef Parser *(*ParserFactory)(void);

static int import_file(ParserFactory factory, const char *payload) {
    Parser *p = factory();
    if (!p) return 1;
    p->parse(p, payload);
    p->destroy(p);
    return 0;
}

int main(void) {
    import_file(make_csv_parser, "id,name\\n1,Alice");
    import_file(make_json_parser, "{\\\"id\\\":1}");
    return 0;
}
