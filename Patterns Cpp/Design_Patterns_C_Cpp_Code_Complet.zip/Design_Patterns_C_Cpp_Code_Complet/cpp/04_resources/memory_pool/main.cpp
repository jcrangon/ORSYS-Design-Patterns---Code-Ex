#include <iostream>
#include <memory_resource>
#include <vector>
int main(){ std::pmr::unsynchronized_pool_resource pool; std::pmr::vector<int> v{&pool}; for(int i=0;i<10;i++)v.push_back(i*i); for(int x:v)std::cout<<x<<' '; std::cout<<'\n'; }
