#include <iostream>
#include <string>
#include <utility>
struct Frame{int no=0;std::string text;};int main(){Frame a,b;Frame*front=&a,*back=&b;for(int i=1;i<=3;i++){back->no=i;back->text="frame-"+std::to_string(i);std::swap(front,back);std::cout<<"display "<<front->no<<' '<<front->text<<'\n';}}
