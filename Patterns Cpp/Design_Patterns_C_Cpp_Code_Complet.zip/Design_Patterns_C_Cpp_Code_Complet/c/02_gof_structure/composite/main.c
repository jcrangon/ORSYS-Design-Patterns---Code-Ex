#include <stdio.h>
#include <stdlib.h>

typedef struct Node Node;
struct Node { int (*cost)(const Node*); void (*destroy)(Node*); };
typedef struct { Node base; int value; } Leaf;
typedef struct { Node base; Node *children[8]; size_t count; } Group;
static int leaf_cost(const Node *n){ return ((const Leaf*)n)->value; }
static void leaf_destroy(Node *n){ free(n); }
static Leaf *leaf_new(int value){ Leaf *l=malloc(sizeof *l); if(l) *l=(Leaf){{leaf_cost,leaf_destroy},value}; return l; }
static int group_cost(const Node *n){ const Group *g=(const Group*)n; int s=0; for(size_t i=0;i<g->count;i++) s+=g->children[i]->cost(g->children[i]); return s; }
static void group_destroy(Node *n){ Group *g=(Group*)n; for(size_t i=0;i<g->count;i++) g->children[i]->destroy(g->children[i]); free(g); }
static Group *group_new(void){ Group *g=calloc(1,sizeof *g); if(g) g->base=(Node){group_cost,group_destroy}; return g; }
static void group_add(Group *g,Node *n){ if(g->count<8) g->children[g->count++]=n; }
int main(void){ Group *root=group_new(); group_add(root,(Node*)leaf_new(10)); Group *sub=group_new(); group_add(sub,(Node*)leaf_new(20)); group_add(sub,(Node*)leaf_new(30)); group_add(root,(Node*)sub); printf("cost=%d\n",root->base.cost((Node*)root)); root->base.destroy((Node*)root); return 0; }
