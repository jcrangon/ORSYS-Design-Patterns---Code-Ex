#include <algorithm>
#include <iostream>
#include <vector>
int main(){std::vector<int>v{4,1,3,2};auto print=[&]{for(int x:v)std::cout<<x<<' ';std::cout<<'\n';};std::sort(v.begin(),v.end(),std::less<>{});print();std::sort(v.begin(),v.end(),std::greater<>{});print();}
