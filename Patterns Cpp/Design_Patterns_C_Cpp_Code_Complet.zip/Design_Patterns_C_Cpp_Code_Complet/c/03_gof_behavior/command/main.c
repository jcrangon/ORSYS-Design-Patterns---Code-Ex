#include <stdio.h>

typedef struct { int value; } Counter;
typedef struct { void *ctx; void (*execute)(void*); void (*undo)(void*); } Command;
static void inc(void *ctx){ ++((Counter*)ctx)->value; }
static void dec(void *ctx){ --((Counter*)ctx)->value; }
int main(void){ Counter c={0}; Command cmd={&c,inc,dec}; cmd.execute(cmd.ctx); cmd.execute(cmd.ctx); printf("after execute=%d\n",c.value); cmd.undo(cmd.ctx); printf("after undo=%d\n",c.value); return 0; }
