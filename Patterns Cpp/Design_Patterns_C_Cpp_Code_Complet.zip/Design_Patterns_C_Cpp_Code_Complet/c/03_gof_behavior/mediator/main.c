#include <stdio.h>
typedef struct { int enabled; } Button;
typedef struct { int visible; } Panel;
typedef struct { Button advanced_button; Panel advanced_panel; } DialogMediator;
static void checkbox_changed(DialogMediator *m,int checked){ m->advanced_button.enabled=checked; m->advanced_panel.visible=checked; }
int main(void){ DialogMediator m={0}; checkbox_changed(&m,1); printf("button=%d panel=%d\n",m.advanced_button.enabled,m.advanced_panel.visible); return 0; }
