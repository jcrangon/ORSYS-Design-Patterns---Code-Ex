#include <stdint.h>
#include <stdio.h>
#include <stdbool.h>
#define CAP 4
typedef struct{uint32_t index,generation;}Handle;typedef struct{int value;uint32_t generation;bool used;}Slot;typedef struct{Slot slots[CAP];}Store;
static Handle create(Store*s,int value){for(uint32_t i=0;i<CAP;i++)if(!s->slots[i].used){s->slots[i].used=true;s->slots[i].value=value;return(Handle){i,s->slots[i].generation};}return(Handle){UINT32_MAX,0};}
static int*resolve(Store*s,Handle h){if(h.index>=CAP)return NULL;Slot*sl=&s->slots[h.index];return sl->used&&sl->generation==h.generation?&sl->value:NULL;}
static void destroy(Store*s,Handle h){if(h.index<CAP&&s->slots[h.index].used&&s->slots[h.index].generation==h.generation){s->slots[h.index].used=false;++s->slots[h.index].generation;}}
int main(void){Store s={0};Handle h=create(&s,99);printf("value=%d\n",*resolve(&s,h));destroy(&s,h);printf("old handle valid=%s\n",resolve(&s,h)?"yes":"no");Handle h2=create(&s,77);printf("new gen=%u old=%u\n",h2.generation,h.generation);return 0;}
