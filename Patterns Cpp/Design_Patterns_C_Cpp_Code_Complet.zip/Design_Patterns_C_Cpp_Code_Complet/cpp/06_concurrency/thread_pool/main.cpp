#include <condition_variable>
#include <functional>
#include <iostream>
#include <mutex>
#include <queue>
#include <thread>
#include <vector>
class ThreadPool{std::mutex m_;std::condition_variable cv_;std::queue<std::function<void()>>q_;bool stop_=false;std::vector<std::jthread>workers_;public:explicit ThreadPool(int n){for(int i=0;i<n;i++)workers_.emplace_back([this]{for(;;){std::function<void()>job;{std::unique_lock lk(m_);cv_.wait(lk,[&]{return stop_||!q_.empty();});if(stop_&&q_.empty())return;job=std::move(q_.front());q_.pop();}job();}});}~ThreadPool(){{std::lock_guard lk(m_);stop_=true;}cv_.notify_all();}void submit(std::function<void()>f){{std::lock_guard lk(m_);q_.push(std::move(f));}cv_.notify_one();}};int main(){ThreadPool p(3);for(int i=0;i<6;i++)p.submit([i]{std::cout<<"job "<<i<<"\n";});}
