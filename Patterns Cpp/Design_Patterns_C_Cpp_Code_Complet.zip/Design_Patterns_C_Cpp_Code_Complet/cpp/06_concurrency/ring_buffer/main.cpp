#include <array>
#include <iostream>
#include <optional>
template<class T,std::size_t N>class Ring{std::array<T,N>data_{};std::size_t h_=0,t_=0;public:bool push(T x){auto n=(h_+1)%N;if(n==t_)return false;data_[h_]=std::move(x);h_=n;return true;}std::optional<T>pop(){if(t_==h_)return std::nullopt;T x=std::move(data_[t_]);t_=(t_+1)%N;return x;}};int main(){Ring<int,8>r;for(int i=1;i<=5;i++)r.push(i);while(auto x=r.pop())std::cout<<*x<<' ';std::cout<<'\n';}
