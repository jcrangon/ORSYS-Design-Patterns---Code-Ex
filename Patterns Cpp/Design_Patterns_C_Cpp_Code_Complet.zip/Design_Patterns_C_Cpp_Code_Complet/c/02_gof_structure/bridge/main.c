#include <stdio.h>

typedef struct { void *ctx; void (*send)(void*,const char*); } Channel;
static void email_send(void *ctx,const char *m){ (void)ctx; printf("EMAIL: %s\n",m); }
static void sms_send(void *ctx,const char *m){ (void)ctx; printf("SMS: %s\n",m); }
typedef struct { const char *prefix; Channel channel; } Notification;
static void notification_send(Notification *n,const char *m){ char buf[128]; snprintf(buf,sizeof buf,"%s: %s",n->prefix,m); n->channel.send(n->channel.ctx,buf); }
int main(void){ Channel email={NULL,email_send}, sms={NULL,sms_send}; Notification alert={"ALERT",email}, report={"REPORT",sms}; notification_send(&alert,"disk full"); notification_send(&report,"daily ok"); return 0; }
