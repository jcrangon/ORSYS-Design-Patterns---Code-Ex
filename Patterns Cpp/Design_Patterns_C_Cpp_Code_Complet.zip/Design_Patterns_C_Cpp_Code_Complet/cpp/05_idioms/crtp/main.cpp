#include <iostream>

template<class Derived>
struct Printable {
    void print() const {
        static_cast<const Derived&>(*this).printImpl();
    }
};

struct User : Printable<User> {
    const char* name;
    explicit User(const char* n) : name(n) {}
    void printImpl() const { std::cout << "User(" << name << ")\n"; }
};

struct Point : Printable<Point> {
    int x, y;
    Point(int x_, int y_) : x(x_), y(y_) {}
    void printImpl() const { std::cout << "Point(" << x << ',' << y << ")\n"; }
};

int main() {
    User{"Alice"}.print();
    Point{2,3}.print();
}
