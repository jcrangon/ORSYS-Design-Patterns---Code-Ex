#include <cstddef>
#include <iostream>
#include <string>
class Vendor { public: std::size_t write(const char* p,std::size_t n,int){ std::cout.write(p,n); std::cout<<'\n'; return n; } };
struct Transport { virtual ~Transport()=default; virtual bool send(const std::string&)=0; };
class VendorAdapter final: public Transport { Vendor& v_; public: explicit VendorAdapter(Vendor& v):v_(v){} bool send(const std::string& s) override { return v_.write(s.data(),s.size(),0)==s.size(); } };
int main(){ Vendor v; VendorAdapter a(v); std::cout<<std::boolalpha<<a.send("HELLO")<<'\n'; }
