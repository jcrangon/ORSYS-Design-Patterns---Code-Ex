#include <iostream>
#include <map>
#include <memory>
#include <string>
#include <tuple>
struct GlyphStyle { std::string font; int size; int color; };
class StyleFactory { std::map<std::tuple<std::string,int,int>,std::shared_ptr<const GlyphStyle>> cache_; public: std::shared_ptr<const GlyphStyle> get(std::string f,int s,int c){ auto k=std::make_tuple(f,s,c); auto& p=cache_[k]; if(!p) p=std::make_shared<GlyphStyle>(GlyphStyle{std::move(f),s,c}); return p; } };
struct Glyph { char ch; int x,y; std::shared_ptr<const GlyphStyle> style; };
int main(){ StyleFactory f; auto s=f.get("Mono",12,0); Glyph a{'A',10,20,s},b{'B',20,20,f.get("Mono",12,0)}; std::cout<<std::boolalpha<<(a.style==b.style)<<'\n'; }
