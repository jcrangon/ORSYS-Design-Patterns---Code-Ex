#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
typedef void(*Completion)(void*ctx,const char*data,int err);typedef struct{Completion cb;void*ctx;}Op;static void*worker(void*p){Op*op=p;usleep(20000);op->cb(op->ctx,"async-data",0);free(op);return NULL;}static void async_read(Completion cb,void*ctx){Op*op=malloc(sizeof*op);*op=(Op){cb,ctx};pthread_t t;pthread_create(&t,NULL,worker,op);pthread_detach(t);}static void done(void*ctx,const char*data,int err){int*finished=ctx;if(!err)printf("completed: %s\n",data);*finished=1;}int main(void){int finished=0;async_read(done,&finished);while(!finished)usleep(1000);return 0;}
