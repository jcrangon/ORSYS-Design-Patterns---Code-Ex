#include <stdio.h>
typedef struct Connection Connection;
typedef struct State { const char *name; int (*send)(Connection*,const char*); } State;
struct Connection { const State *state; };
static int disconnected_send(Connection*c,const char*m){(void)c;(void)m;puts("not connected");return 0;}
static int connected_send(Connection*c,const char*m){(void)c;printf("sent: %s\n",m);return 1;}
static const State DISCONNECTED={"disconnected",disconnected_send}, CONNECTED={"connected",connected_send};
static void connect_now(Connection*c){c->state=&CONNECTED;}
int main(void){Connection c={&DISCONNECTED};c.state->send(&c,"hello");connect_now(&c);c.state->send(&c,"hello");return 0;}
