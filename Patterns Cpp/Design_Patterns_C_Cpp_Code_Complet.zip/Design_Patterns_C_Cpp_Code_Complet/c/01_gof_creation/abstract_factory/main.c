#include <stdio.h>
#include <stdlib.h>

typedef struct Button { const char *style; } Button;
typedef struct Dialog { const char *style; } Dialog;

typedef struct {
    Button *(*make_button)(void);
    Dialog *(*make_dialog)(void);
} UiFactory;

static Button *button_new(const char *style){ Button *b=malloc(sizeof *b); if(b) b->style=style; return b; }
static Dialog *dialog_new(const char *style){ Dialog *d=malloc(sizeof *d); if(d) d->style=style; return d; }
static Button *dark_button(void){ return button_new("dark"); }
static Dialog *dark_dialog(void){ return dialog_new("dark"); }
static Button *light_button(void){ return button_new("light"); }
static Dialog *light_dialog(void){ return dialog_new("light"); }

static void render_screen(const UiFactory *f) {
    Button *b=f->make_button(); Dialog *d=f->make_dialog();
    if(!b||!d){ free(b); free(d); return; }
    printf("button=%s, dialog=%s\n", b->style, d->style);
    free(b); free(d);
}

int main(void){
    UiFactory dark={dark_button,dark_dialog};
    UiFactory light={light_button,light_dialog};
    render_screen(&dark); render_screen(&light);
    return 0;
}
