#include <stdio.h>

typedef struct { int order_id; } Event;
typedef void (*EventFn)(void*,const Event*);
typedef struct { EventFn fn; void *ctx; } Subscriber;
typedef struct { Subscriber subs[8]; size_t n; } Bus;
static void subscribe(Bus *b,EventFn fn,void *ctx){ if(b->n<8) b->subs[b->n++]=(Subscriber){fn,ctx}; }
static void publish(Bus *b,const Event *e){ for(size_t i=0;i<b->n;i++) b->subs[i].fn(b->subs[i].ctx,e); }
static void email(void *ctx,const Event *e){ (void)ctx; printf("email order %d\n",e->order_id); }
static void analytics(void *ctx,const Event *e){ int *count=ctx; ++*count; printf("analytics count=%d for %d\n",*count,e->order_id); }
int main(void){ Bus b={0}; int count=0; subscribe(&b,email,NULL); subscribe(&b,analytics,&count); Event e={42}; publish(&b,&e); return 0; }
