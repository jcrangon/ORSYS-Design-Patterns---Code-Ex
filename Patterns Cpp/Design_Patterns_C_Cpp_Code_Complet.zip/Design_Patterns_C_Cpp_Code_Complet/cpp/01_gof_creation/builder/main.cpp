#include <iostream>
#include <stdexcept>
#include <string>

class Request {
    std::string url_; int timeout_; bool tls_;
    Request(std::string u,int t,bool tls):url_(std::move(u)),timeout_(t),tls_(tls){}
public:
    class Builder;
    void print() const { std::cout<<url_<<" timeout="<<timeout_<<" tls="<<std::boolalpha<<tls_<<'\n'; }
};
class Request::Builder {
    std::string url_; int timeout_=1000; bool tls_=false;
public:
    Builder& url(std::string v){ url_=std::move(v); return *this; }
    Builder& timeout(int ms){ timeout_=ms; return *this; }
    Builder& tls(bool v){ tls_=v; return *this; }
    Request build(){ if(url_.empty()||timeout_<=0) throw std::invalid_argument("invalid request"); return Request{url_,timeout_,tls_}; }
};
int main(){ Request::Builder b; auto r=b.url("https://api.example").timeout(1500).tls(true).build(); r.print(); }
