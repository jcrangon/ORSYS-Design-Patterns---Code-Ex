#include <iostream>
#include <memory>
#include <string>

struct Button { virtual ~Button()=default; virtual std::string style() const=0; };
struct Dialog { virtual ~Dialog()=default; virtual std::string style() const=0; };
struct DarkButton final: Button { std::string style() const override { return "dark"; } };
struct DarkDialog final: Dialog { std::string style() const override { return "dark"; } };
struct LightButton final: Button { std::string style() const override { return "light"; } };
struct LightDialog final: Dialog { std::string style() const override { return "light"; } };

struct UiFactory {
    virtual ~UiFactory()=default;
    virtual std::unique_ptr<Button> button() const=0;
    virtual std::unique_ptr<Dialog> dialog() const=0;
};
struct DarkUiFactory final: UiFactory {
    std::unique_ptr<Button> button() const override { return std::make_unique<DarkButton>(); }
    std::unique_ptr<Dialog> dialog() const override { return std::make_unique<DarkDialog>(); }
};
struct LightUiFactory final: UiFactory {
    std::unique_ptr<Button> button() const override { return std::make_unique<LightButton>(); }
    std::unique_ptr<Dialog> dialog() const override { return std::make_unique<LightDialog>(); }
};

void render(const UiFactory& f){ auto b=f.button(); auto d=f.dialog(); std::cout<<b->style()<<' '<<d->style()<<'\n'; }
int main(){ DarkUiFactory dark; LightUiFactory light; render(dark); render(light); }
